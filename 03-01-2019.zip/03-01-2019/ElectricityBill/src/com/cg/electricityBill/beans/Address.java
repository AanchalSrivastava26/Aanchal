package com.cg.electricityBill.beans;

public class Address {

}
