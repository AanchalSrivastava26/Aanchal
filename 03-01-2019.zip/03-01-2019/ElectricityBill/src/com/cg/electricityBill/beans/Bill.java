package com.cg.electricityBill.beans;

public class Bill {
	private int billNo,billDueDate;
	private float billAmount;
	private String billUnit,billMonth;

}
