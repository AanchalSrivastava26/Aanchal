package com.cg.electricityBill.beans;

public class Customer {
	private int customerNo,mobileNo;
	private String firstName, lastName,pancardNo,emailId;

}
