package com.cg.electricityBill.beans;

public class Meter {
	private int meterNo,consumptionUnits,meterLoad;
	private String phase;
	


}
