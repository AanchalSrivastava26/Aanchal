package com.cg.electricityBill.client;

public class MainClass {

}
