package com.cg.electricityBill.daoservices;

public interface ElectricityBillDAO {

}
