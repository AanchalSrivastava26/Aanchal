package com.cg.electricityBill.daoservices;

public class ElectricityBillDAOImpl implements ElectricityBillDAO {

}
