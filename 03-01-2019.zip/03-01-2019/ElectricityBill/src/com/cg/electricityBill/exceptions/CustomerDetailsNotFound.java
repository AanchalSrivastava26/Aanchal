package com.cg.electricityBill.exceptions;

public class CustomerDetailsNotFound {

}
