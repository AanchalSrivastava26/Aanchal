package com.cg.electricityBill.services;

public interface ElectricityBillServices {

}
