package com.cg.electricityBill.services;

public class ElectricityBillServicesImpl implements ElectricityBillServices {

}
