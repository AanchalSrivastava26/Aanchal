package cm.cg.electricitybill.services;

import java.util.List;

import com.cg.electricitybill.beans.Address;
import com.cg.electricitybill.beans.Bill;
import com.cg.electricitybill.beans.Customer;
import com.cg.electricitybill.beans.Meter;
import com.cg.electricitybill.exceptions.CustomerDetailsNotFoundException;

public class ElectricityBillServicesImpl implements ElectricityBillServices {

	@Override
	public int acceptCustomerDetails(int mobileNo, String firstName, String lastName, String pancardNo, String emailId,
			int pincode, int wardNo, String city, int billNo, int billDueDate, String billUnit, String billMonth,
			int meterNo, int consumptionUnits, int meterLoad, String phase, Bill bill) {
		
		Customer customer=new Customer(mobileNo, firstName, lastName, pancardNo, emailId,
				new Address(pincode, wardNo, city),new Meter(meterNo, consumptionUnits, meterLoad, phase,
						new Bill(billNo, billDueDate, billUnit, billMonth)));
	
		return 0;
	}

	@Override
	public int calculateBill(int customerNo) throws CustomerDetailsNotFoundException {
		
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerNo) throws CustomerDetailsNotFoundException {
	
		return null;
	}

	@Override
	public List<Customer> getAllAssociatesDetails() {
	
		return null;
	}

}
