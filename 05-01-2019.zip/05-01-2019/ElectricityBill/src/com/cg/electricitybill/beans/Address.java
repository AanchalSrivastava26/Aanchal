package com.cg.electricitybill.beans;

public class Address {
	private int pincode,wardNo;
	private String city;
	public Address(int pincode, int wardNo, String city) {
		super();
		this.pincode = pincode;
		this.wardNo = wardNo;
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getWardNo() {
		return wardNo;
	}
	public void setWardNo(int wardNo) {
		this.wardNo = wardNo;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

}
