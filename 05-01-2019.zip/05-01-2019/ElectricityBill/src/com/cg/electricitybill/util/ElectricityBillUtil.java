package com.cg.electricitybill.util;

import java.util.HashMap;

import com.cg.electricitybill.beans.Customer;

public class ElectricityBillUtil {
	public static HashMap<Integer, Customer>customers=new HashMap<>();
	private static int CUSTOMER_NO_COUNTER=100;
	public static int getCUSTOMER_NO_COUNTER() {
		return ++CUSTOMER_NO_COUNTER;
	}


}
