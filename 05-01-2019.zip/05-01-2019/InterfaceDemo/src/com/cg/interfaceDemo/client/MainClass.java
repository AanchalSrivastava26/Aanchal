package com.cg.interfaceDemo.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.interfaceDemo.Services.MathServices;
import com.cg.interfaceDemo.Services.MathServicesImpl;
import com.cg.interfaceDemo.exceptions.InvalidNumberRangeException;

public class MainClass {

	public static void main(String[] args)  {
		try {
		MathServices mathServices=new MathServicesImpl();
		System.out.println(mathServices.add(100, 200));
		System.out.println(mathServices.sub(100,200));
		System.out.println(mathServices.multi(100, 200));
		System.out.println(mathServices.div(100, 200));

	
			Scanner s=new Scanner(System.in);
			System.out.println("enter first number");
			int n1=s.nextInt();
			System.out.println("enter second number");
			int n2=s.nextInt();
			int result=n1+n2;
			System.out.println(result);
		}
		catch(InputMismatchException e) {
			System.err.println("enter only numbers");
		}
		catch(ArithmeticException e) {
			System.err.println(e.getMessage()+" "+"enter second number other than 0");
		}
		catch(Exception e) {
			System.err.println("cannot say anything");
		}
		System.out.println("code after catch block");





	}

}
