package com.cg.interfaceDemo.test;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.interfaceDemo.Services.MathServices;
import com.cg.interfaceDemo.Services.MathServicesImpl;
import com.cg.interfaceDemo.exceptions.InvalidNumberRangeException;

import org.junit.Assert;

public class MathServicesTest {
	private static MathServices mathServices;
	private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mathServices=new MathServicesImpl();
		
	}
	@Before
	public void setUpTestData() {
		firstInvalidNumber=-100;
		firstValidNumber=100;
		secondInvalidNumber=-200;
		secondValidNumber=200;
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForFirstNumber() throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForSecondNumber() throws InvalidNumberRangeException{
		mathServices.add(firstValidNumber, secondInvalidNumber);
	}

	@Test
	public void testAddForBothNumbers() throws InvalidNumberRangeException{
		int expectedAns=300;
		int actualAns=mathServices.add(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForFirstNumber() throws InvalidNumberRangeException{
		mathServices.sub(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForSecondNumber() throws InvalidNumberRangeException{
		mathServices.sub(firstValidNumber, secondInvalidNumber);
	}

	@Test
	public void testSubForBothValidNumbers() throws InvalidNumberRangeException{
		int expectedAns=-100;
		int actualAns=mathServices.sub(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testMultiForFirstNumber() throws InvalidNumberRangeException{
		mathServices.multi(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testMultiForSecondNumber() throws InvalidNumberRangeException{
		mathServices.multi(firstValidNumber, secondInvalidNumber);
	}

	@Test
	public void testMultiForBothValidNumbers() throws InvalidNumberRangeException{
		int expectedAns=20000;
		int actualAns=mathServices.multi(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForFirstNumber() throws InvalidNumberRangeException{
		mathServices.div(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForSecondNumber() throws InvalidNumberRangeException{
		mathServices.div(firstValidNumber, secondInvalidNumber);
	}

	@Test
	public void testDivForBothValidNumbers() throws InvalidNumberRangeException{
		int expectedAns=0;
		int actualAns=mathServices.div(firstValidNumber, secondValidNumber);
	Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	
	@AfterClass
	public static void removeTestEnv() {
		mathServices=null;
	}
	
}
