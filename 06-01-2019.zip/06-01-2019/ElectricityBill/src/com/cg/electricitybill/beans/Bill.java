package com.cg.electricitybill.beans;


public class Bill {
	private int billNo,billDueDate;
	private float billAmount;
	private String billUnit,billMonth;
	public Bill(int billNo, int billDueDate, String billUnit, String billMonth) {
		super();
		this.billNo = billNo;
		this.billDueDate = billDueDate;
		
		this.billUnit = billUnit;
		this.billMonth = billMonth;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public int getBillDueDate() {
		return billDueDate;
	}
	public void setBillDueDate(int billDueDate) {
		this.billDueDate = billDueDate;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}
	public String getBillUnit() {
		return billUnit;
	}
	public void setBillUnit(String billUnit) {
		this.billUnit = billUnit;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}

}
