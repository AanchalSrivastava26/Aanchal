package com.cg.electricitybill.beans;


public class Customer {
	private int customerNo,mobileNo;
	private String firstName, lastName,pancardNo,emailId;
	private Address address;
	private Meter meter;

	public Customer(int customerNo, int mobileNo, String firstName, String lastName, String pancardNo, String emailId,Address address,Meter meter) {
		super();
		this.customerNo = customerNo;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pancardNo = pancardNo;
		this.emailId = emailId;
		this.address=address;
		this.meter=meter;
	}

	
	
	
	public Customer(int mobileNo, String firstName, String lastName, String pancardNo, String emailId, Address address,
			Meter meter) {
		super();
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pancardNo = pancardNo;
		this.emailId = emailId;
		this.address = address;
		this.meter = meter;
	}




	public Customer(int customerNo, int mobileNo , String firstName, String lastName) {
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.customerNo=customerNo;
	}




	public int getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Meter getMeter() {
		return meter;
	}
	public void setMeter(Meter meter) {
		this.meter = meter;
	}

	@Override
	public String toString() {
		return "customerNo=" + customerNo + ", mobileNo=" + mobileNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", pancardNo=" + pancardNo + ", emailId=" + emailId + ", address="
				+ address + ", meter=" + meter ;
	}

	
	
}
