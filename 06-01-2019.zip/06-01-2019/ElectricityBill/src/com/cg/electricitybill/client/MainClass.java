package com.cg.electricitybill.client;

import com.cg.electricitybill.beans.Address;
import com.cg.electricitybill.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		//Customer customer=new Customer(10001, 1234567891, "aanchal", "srivastava", "jyup1234", "aanchal@gmail.com", new Address(123456, 10, "LUCKNOW"), new Meter(34, 380,3, "one", new Bill(1234, 31, "12lko", "december")));
		Customer customer=new Customer(101, 437828389, "aanchal", "srivastava");	
		System.out.println(customer.getFirstName()+" "+customer.getMeter().getBill().getBillNo());
			
			Customer[] customers=new Customer[5];
			customers[0]=new Customer(101, 363787333, "aanchal", "srivastava");
			customers[1]=new Customer(102, 800278374, "abc", "xyz");
			customers[2]=new Customer(103, 836526662, "def", "uvw");
			customers[3]=new Customer(104, 378278897, "ghi", "tuv");
			customers[4]=new Customer(105, 276378278, "jkl", "stu");
			System.out.println(customers[0].getCustomerNo()+" "+customers[0].getFirstName());


	}

}
