package com.cg.electricitybill.daoservices;

import java.util.List;

import com.cg.electricitybill.beans.Customer;
import com.cg.electricitybill.util.ElectricityBillUtil;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public Customer save(Customer customer) {
		customer.setCustomerNo(ElectricityBillUtil.getCUSTOMER_NO_COUNTER());
		ElectricityBillUtil.customers.put(customer.getCustomerNo(), customer);
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		ElectricityBillUtil.customers.put(customer.getCustomerNo(), customer);
		return true;
	}

	@Override
	public Customer findOne(int customerNo) {
	
		return null;
	}

	@Override
	public List<Customer> findAll() {
	
		return null;
	}

}
