package com.cg.electricitybill.beans;

public class Meter {
	private int meterNo,consumptionUnits,meterLoad;
	private String phase;
	private Bill bill;

	public Meter(int meterNo, int consumptionUnits, int meterLoad, String phase,Bill bill) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.meterLoad = meterLoad;
		this.phase = phase;
		this.bill=bill;
	}
	public int getMeterNo() {
		return meterNo;
	}
	public void setMeterNo(int meterNo) {
		this.meterNo = meterNo;
	}
	public int getConsumptionUnits() {
		return consumptionUnits;
	}
	public void setConsumptionUnits(int consumptionUnits) {
		this.consumptionUnits = consumptionUnits;
	}
	public int getMeterLoad() {
		return meterLoad;
	}
	public void setMeterLoad(int meterLoad) {
		this.meterLoad = meterLoad;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}

}
