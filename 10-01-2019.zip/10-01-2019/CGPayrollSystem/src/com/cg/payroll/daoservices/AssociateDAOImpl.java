package com.cg.payroll.daoservices;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;

public class AssociateDAOImpl implements AssociateDAO {

	@Override
	public Associate save(Associate associate) {
		associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
		PayrollUtil.associates.put(associate.getAssociateID(),associate);
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		PayrollUtil.associates.put(associate.getAssociateID(),associate);
		return true;
	}

	@Override
	public Associate findOne(int associateId) {
		return PayrollUtil.associates.get(associateId);
	}

	@Override
	public List<Associate> findAll() {   //return type is List which is generic. If it would be arraylist it would return arraylist only
		ArrayList<Associate> associateList=new ArrayList<>(PayrollUtil.associates.values());//values() method is creating a arraylist out of the vlaues of hashmap. 
		return associateList ;


		/*	ArrayList<Associate> associateList1=new ArrayList<>();
		Set<Integer> keySet=PayrollUtil.associates.keySet();
		for( Integer key : keySet) {
			associateList1.add(PayrollUtil.associates.get(key));
		}
		ArrayList<Associate> associateList3=(ArrayList<Associate>)PayrollUtil.associates.values();*/
	}

}
