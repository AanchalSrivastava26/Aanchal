import java.util.Arrays;

public  class Sorted {


}