package com.cg.eis.service;

public interface EmployeeService {
	public double calulateInsurance(String designation,double salary);

}
