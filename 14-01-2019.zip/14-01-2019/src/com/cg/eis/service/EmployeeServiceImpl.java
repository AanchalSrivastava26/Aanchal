package com.cg.eis.service;

public class EmployeeServiceImpl implements EmployeeService{


	@Override
	public double calulateInsurance(String designation, double salary) {
		double insuranceAmount;
		if(designation=="analyst" && salary<=200000.0)
			insuranceAmount=20/100*salary;
		else if(designation=="analyst" && salary<=500000.0)
			insuranceAmount=30/100*salary;
		else if(designation=="analyst" && salary<=700000.0)
			insuranceAmount=35/100*salary;
		else
			insuranceAmount=40/100*salary;
		System.out.println("insurance amount :"+insuranceAmount);
		return insuranceAmount;
	}
	

}
