package com.cg.lab4.beans;

public class CurrentAccount extends Account {
	final double overdraftLimit=30000.0;
	public CurrentAccount(long accNum, double balance, Person accountHolder) {
		super(accNum, balance, accountHolder);
	}
	@Override
	public void withdraw(double amount) {
		super.withdraw(amount);
		if(getBalance()>=overdraftLimit)
			System.out.println("you cannot withdraw amount because it's more than overdraft limit");
	}
}
