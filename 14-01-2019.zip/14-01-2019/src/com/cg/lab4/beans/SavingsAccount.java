package com.cg.lab4.beans;

public class SavingsAccount extends Account {
	final double  minimumBalance=100.0;

	public SavingsAccount(long accNum, double balance, Person accountHolder) {
		super(accNum, balance, accountHolder);
	}

	@Override
	public void withdraw(double amount) {
		super.withdraw(amount);
		if(getBalance()<=minimumBalance)
			System.out.println("you can not withdraw because your balance reached to minimum amount");
	}

}
