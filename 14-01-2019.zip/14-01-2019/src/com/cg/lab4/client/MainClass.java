package com.cg.lab4.client;
import com.cg.lab4.beans.Account;
import com.cg.lab4.beans.Person;

public class MainClass {
	public static void main(String[] args) {
		Account account=new Account(1256136, 2000.0, new Person("smith", 23.0f));
		account.deposit(2000.0);
		Account account1=new Account(532615316, 3000.0, new Person("Kathy", 25.0f));
		account1.withdraw(2000.0);
	}
}
