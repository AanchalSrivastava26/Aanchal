package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, int yearlyInvestmentUnder80C,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode) {
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
				new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber,bankName, ifscCode));
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {


		Associate associate=this.getAssociateDetails(associateId);
		associate.getSalary().setHra((40/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyanceAllowance((30/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setPersonalAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getEpf()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getHra()+associate.getSalary().getConveyanceAllowance()+
				associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance());
	
		int annualTax=0;
		int annualSalary=associate.getSalary().getGrossSalary()*12;
		int tax=annualSalary-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()*12-associate.getSalary().getCompanyPf()*12;
		int monthlyTax=annualTax/12;
		if(tax>0 && tax<=25000)
			annualTax=0;
		else if(tax>250000 && tax<=500000)
			annualTax=annualTax+(tax-250000)*10/100;
		else if(tax>500000 && tax<=1000000)
			annualTax=25000+(tax-500000)*20/100;
		else
			annualTax=125000+(tax-1000000)*30/100;
		int netSalary=associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-monthlyTax;
		return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("Associate details not found for associateId"+associateId);
		return associate;
	}

	@Override
	public Associate[] getAllAssociatesDetails() {

		return associateDAO.findAll();
	}

}
