package com.cg.payroll.test;

import com.cg.payroll.beans.Associate;


import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class PayrollServicesTest {
	static PayrollServices payrollServices;
/*	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices=new PayrollServicesImpl();

	}
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(101, 30000, "aanchal", "srivastava", "xyz", "analyst", "hduu265", 
				"aanchal@gmail.com", new Salary( 200000, 8000, 3000),new  BankDetails("hdfc", "hdfc1000"));

		Associate associate2=new Associate(102, 30000, "abc", "def", "xyz", "analyst", "jdj2346", 
				"abc@gmail.com", new Salary(20000, 1000,2000),new  BankDetails("hdfc", "hdfc6000"));

		PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
		PayrollUtil.associates.put(associate2.getAssociateID(), associate2);
		PayrollUtil.ASSOCIATE_ID_COUNTER=103;
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedAssociateId=104;
		int actualAssociateId=payrollServices.acceptAssociateDetails("prachi", "srivastava", 10000, "yxz", "analyst",
				"abjhs109","prachi@gmail.com", 20000, 1900, 2700,7828222,"hdfc", "dh233");
		Assert.assertEquals(expectedAssociateId, actualAssociateId);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(12121);
	}
	@Test
	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102, 30000, "abc", "def", "xyz", "analyst", "jdj2346", 
				"abc@gmail.com", new Salary(20000, 1000,2000),new  BankDetails("hdfc", "hdfc6000"));
		Associate actualAssociate=payrollServices.getAssociateDetails(102);
		Assert.assertEquals(expectedAssociate, actualAssociate);

	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		payrollServices.getAssociateDetails(250);
	}
	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException{
		int expectedSalary=420000;
		int actualNetSalary=payrollServices.calculateNetSalary(101);
		Assert.assertEquals(expectedSalary,actualNetSalary);
	}

	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
		ArrayList<Associate>actualAssociateList=(ArrayList<Associate>)payrollServices.getAllAssociatesDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData() {
		PayrollUtil.ASSOCIATE_ID_COUNTER=100;
		PayrollUtil.associates.clear();
	}
	@AfterClass
	public static void testDownTestEnv() {
		payrollServices=null;
	}*/
}
