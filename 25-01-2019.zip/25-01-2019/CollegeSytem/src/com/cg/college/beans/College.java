package com.cg.college.beans;

import javax.persistence.Entity;

@Entity
public class College {
	
	private int collegeCode;
	private String collegeName,collegeCity,collegeState;
	private Student student;
	private Faculty faculty;
	public College(int collegeCode, String collegeName, String collegeCity, String collegeState, Student student,
			Faculty faculty) {
		super();
		this.collegeCode = collegeCode;
		this.collegeName = collegeName;
		this.collegeCity = collegeCity;
		this.collegeState = collegeState;
		this.student = student;
		this.faculty = faculty;
	}
	
	
	public College(String collegeName, String collegeCity, String collegeState, Student student, Faculty faculty) {
		super();
		this.collegeName = collegeName;
		this.collegeCity = collegeCity;
		this.collegeState = collegeState;
		this.student = student;
		this.faculty = faculty;
	}


	public int getCollegeCode() {
		return collegeCode;
	}
	public void setCollegeCode(int collegeCode) {
		this.collegeCode = collegeCode;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public String getCollegeCity() {
		return collegeCity;
	}
	public void setCollegeCity(String collegeCity) {
		this.collegeCity = collegeCity;
	}
	public String getCollegeState() {
		return collegeState;
	}
	public void setCollegeState(String collegeState) {
		this.collegeState = collegeState;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	
	

}
