package com.cg.college.beans;

public class Faculty {
	private int facultyId;
	private String facultyName,facultyDepartment;
	public Faculty(int facultyId, String facultyName, String facultyDepartment) {
		super();
		this.facultyId = facultyId;
		this.facultyName = facultyName;
		this.facultyDepartment = facultyDepartment;
	}
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public String getFacultyDepartment() {
		return facultyDepartment;
	}
	public void setFacultyDepartment(String facultyDepartment) {
		this.facultyDepartment = facultyDepartment;
	}
	

}
