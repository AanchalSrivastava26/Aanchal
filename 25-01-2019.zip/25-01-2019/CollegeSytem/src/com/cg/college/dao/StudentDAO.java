package com.cg.college.dao;

import java.util.List;

import com.cg.college.beans.Student;

public interface StudentDAO {
	Student save(Student student);
	boolean update(Student student);
	Student findOne(int studentId);
	List<Student > findAll();
}
