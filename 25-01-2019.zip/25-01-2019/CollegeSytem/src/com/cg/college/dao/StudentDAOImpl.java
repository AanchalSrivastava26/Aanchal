package com.cg.college.dao;

import java.util.List;

import com.cg.college.beans.Student;

public class StudentDAOImpl implements StudentDAO{

	@Override
	public Student save(Student student) {
	
		return null;
	}

	@Override
	public boolean update(Student student) {
	
		return false;
	}

	@Override
	public Student findOne(int studentId) {
	
		return null;
	}

	@Override
	public List<Student> findAll() {
		
		return null;
	}

}
