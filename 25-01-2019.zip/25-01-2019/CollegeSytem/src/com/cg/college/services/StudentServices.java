package com.cg.college.services;

import java.util.List;
import com.cg.college.beans.Student;


public interface StudentServices {

	int acceptStudentDetails(int collegeCode, String collegeName, String collegeCity, String collegeState,
			int studentId, String studentName, String studentDepartment, int noOfSubjects, int marks,int facultyId, 
			String facultyName, String facultyDepartment);
	int calculateTotalMarks(int StudentId);
	Student getStudentDetails(int studentId);
	List<Student> getAllStudentDetails();

}
