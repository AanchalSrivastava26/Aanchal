package com.cg.college.services;

import java.util.List;

import com.cg.college.beans.Faculty;
import com.cg.college.beans.Student;

public class StudentServicesImpl implements StudentServices{

	@Override
	public int acceptStudentDetails(int collegeCode, String collegeName, String collegeCity, String collegeState,
			int studentId, String studentName, String studentDepartment, int noOfSubjects, int marks, int facultyId,
			String facultyName, String facultyDepartment) {
	
		return 0;
	}

	@Override
	public int calculateTotalMarks(int StudentId) {
	
		return 0;
	}

	@Override
	public Student getStudentDetails(int studentId) {
	
		return null;
	}

	@Override
	public List<Student> getAllStudentDetails() {
	
		return null;
	}

	

}
