package com.cg.banking.client;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Account ac=new Account(1234567, 20000, "Savings");
		System.out.println(ac.getAccountNo()+" "+ac.getAccountBalance()+" "+ac.getAccountType());

		Address ad=new Address("Lucknow", "Uttar Pradesh", "India", 123456);
		System.out.println(ad.getCity()+" "+ad.getState()+" "+ad.getCountry()+" "+
				ad.getPinCode());

		Customer c=new Customer("aancsriv","aanchal", "srivastava", "1234567", "abc123@gmail.com", "1234adfgj", "26-sep-1996", 1234567);
		System.out.println(c.getCustomerId()+" "+c.getFirstName()+" "+c.getLastName()+" "+
				c.getMobileNo()+" "+c.getEmailId()+" "+c.getPancardNo()+" "+c.getDateOfBirth()+" "+
				c.getAdharNo());

		Transaction t=new Transaction("123abc","savings","lucknow", "abc", "complete", 10, 10000);
		System.out.println(t.getTransactionId()+" "+t.getTransactionType()+" "+t.getTransactionLocation()+" "+t.getModeOfTransaction()
		+" "+t.getTransactionStatus()+" "+t.getTransactionStatus()+" "+t.getTimeStamp()+" "+t.getAmount());
	}

}

