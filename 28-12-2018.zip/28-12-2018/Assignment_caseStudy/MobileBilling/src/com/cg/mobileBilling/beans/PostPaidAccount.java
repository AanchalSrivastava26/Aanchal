package com.cg.mobileBilling.beans;

public class PostPaidAccount {
	private int mobileNo;

	public PostPaidAccount(int mobileNo) {
		super();
		this.mobileNo = mobileNo;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

}
