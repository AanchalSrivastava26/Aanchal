package com.cg.mobileBilling.client;

public class MainClass {

	public static void main(String[] args) {
	

	}

}
