package com.cg.banking.client;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		
		Account[] accounts=new Account[3];
		accounts[0]=new Account(12345678,300000,"savings");
		accounts[1]=new Account(10001,3000,"current");
		accounts[2]=new Account(10002,4000,"savings");
		
		for (Account account1 : accounts) {
			System.out.println(account1.getAccountNo()+" "+account1.getAccountBalance()+" "+account1.getAccountType());
			
		}
Transaction[] transactions=new Transaction[3];
transactions[0]=new Transaction("100a","pune");
transactions[1]=new Transaction("100b","mumbai");
transactions[2]=new Transaction("100c","delhi");

Customer customer=new Customer("Aanchal","Srivastava");
	

}}

