

public class BinarySearch {
	public static void main(String[] args) {
		int a[]= {1,4,2,6,7};
		int f=0,l=4,m=(f+l)/2;
		int num=2;
		while (f<=l) {
			if(a[m]<num)
				f=m+1;
			else if(a[m]==num) {
				System.out.println("element found at="+(m+1));
				break;
			}
			else {
				l=m-1;
				m=(f+l)/2;
			}
		}
	}
}


