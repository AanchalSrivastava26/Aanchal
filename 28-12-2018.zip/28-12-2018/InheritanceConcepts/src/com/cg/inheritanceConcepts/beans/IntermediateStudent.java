package com.cg.inheritanceConcepts.beans;

public final class IntermediateStudent extends Student {
	private String stream;
	private int totalMarks,practicalMarks;

	public IntermediateStudent(int studentRollNo, int noOfSubjects, String firstName, String lastName,String stream,int practicalMarks) {
		super(studentRollNo, noOfSubjects, firstName, lastName);
		this.stream=stream;
		this.practicalMarks=practicalMarks;

	}

	
	public String getStream() {
		return stream;
	}


	public void setStream(String stream) {
		this.stream = stream;
	}


	public int getTotalMarks() {
		return totalMarks;
	}


	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}


	

	public int getPracticalMarks() {
		return practicalMarks;
	}


	public void setPracticalMarks(int practicalMarks) {
		this.practicalMarks = practicalMarks;
	}


	public void calculateMarks() {
		totalMarks=getNoOfSubjects()*80+practicalMarks;
		setTotalMarks(totalMarks);
		
		
	}



}
