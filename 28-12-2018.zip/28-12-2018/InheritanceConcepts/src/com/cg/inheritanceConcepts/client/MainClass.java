package com.cg.inheritanceConcepts.client;

import com.cg.inheritanceConcepts.beans.GraduateStudent;
import com.cg.inheritanceConcepts.beans.IntermediateStudent;
import com.cg.inheritanceConcepts.beans.Student;

public class MainClass {

	public static void main(String[] args) {
		Student s;
		
		/*Student s=new Student(12, 10, "aanchal", "srivastava");
		s.calculateMarks();
		System.out.println(s.getTotalMarks());

		GraduateStudent gs=new GraduateStudent(13, 6, "preeti", "abc", "CSE", "AKTU", 90,70);
		gs.calculateMarks();
		System.out.println(gs.getTotalMarks());
		
		IntermediateStudent is=new IntermediateStudent(34, 10, "madhu", "xyz", "PCM",60);
		is.calculateMarks();
		System.out.println(is.getTotalMarks());*/
		
		
		s=new GraduateStudent(13, 6, "preeti", "abc", "CSE", "AKTU", 90,70);
		s.calculateMarks();
		System.out.println(s.getFirstName()+" "+"Graduate student"+"  "+"total marks ="+s.getTotalMarks());
		
		s=new IntermediateStudent(34, 10, "madhu", "xyz", "PCM",60);
		s.calculateMarks();
		System.out.println(s.getFirstName()+" "+"Intermediate student"+" "+"total marks ="+s.getTotalMarks());


	}

}
