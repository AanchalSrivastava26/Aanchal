package com.cg.inheritanceDemo.beans;

public class PEmployee extends Employee{
	private int hra,ta,da,totalSalary;


	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);

	}



	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
	public void calculateSalary() {
		hra=getBasicSalary()*10/100;
		ta=getBasicSalary()*10/100;
		da=getBasicSalary()*10/100;
		totalSalary=hra+ta+da+getBasicSalary();
		setTotalSalary(totalSalary);
	}



	@Override
	public String toString() {
		return "hra=" + hra + ", ta=" + ta + ", da=" + da + ", totalSalary=" + totalSalary
				+ ", getEmployeeId()=" + getEmployeeId() + ", getBasicSalary()=" + getBasicSalary()
				+ ", getTotalSalary()=" + getTotalSalary() + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", toString()=" + super.toString() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode();
	}
	
	

}
