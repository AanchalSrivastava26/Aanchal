package com.cg.interfaceDemo.Services;

public interface MathServices {
	int add(int n1,int n2);
	int sub(int n1,int n2);
	int multi(int n1,int n2);
	int div(int n1,int n2);

}
