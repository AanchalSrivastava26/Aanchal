package com.cg.interfaceDemo.client;

import com.cg.interfaceDemo.Services.MathServices;
import com.cg.interfaceDemo.Services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
	
		MathServices mathServices=new MathServicesImpl();
		System.out.println(mathServices.add(1, 2));
		System.out.println(mathServices.sub(2,1));
		System.out.println(mathServices.multi(3, 4));
		System.out.println(mathServices.div(20, 4));
		

	}

}
