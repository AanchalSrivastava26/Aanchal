
public class Practice {

	public static void main(String[] args) {
		int i,j;
		for ( i = 0; i < 10; i++) {
			for (j = 0;  j< 15; j++) {
				if(i<=2 && j<=5)
					System.out.print("*");
				else
					System.out.print("=");

			}
			System.out.println();
		}

	}

}
