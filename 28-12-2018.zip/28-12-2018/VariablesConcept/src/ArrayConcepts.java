import java.io.*;
public class ArrayConcepts {

	public static void main(String[] args)throws IOException {
		int a[][][]=new int[2][2][3];
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		int i,j,k;
		System.out.println("enter elements of array");
		for(i=0;i<a.length;i++) 
			for(j=0;j<a[i].length;j++) 
				for(k=0;k<a[i][j].length;k++)
					a[i][j][k]=Integer.parseInt(br.readLine());
		System.out.println("display elements of array");
		for(i=0;i<a.length;i++) 
			for(j=0;j<a[i].length;j++) 
				for(k=0;k<a[i][j].length;k++)
					System.out.print(a[i][j][k]);
	}

}




