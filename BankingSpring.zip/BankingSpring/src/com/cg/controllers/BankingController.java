package com.cg.controllers;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.beans.Account;
import com.cg.beans.Transaction;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.BankingServicesDownException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidAccountTypeException;
import com.cg.exceptions.InvalidAmountException;
import com.cg.exceptions.InvalidPinNumberException;
import com.cg.services.BankingServices;


@Controller
public class BankingController {
	@Autowired
	BankingServices bankingService;

	public BankingServices getBankingService() {
		return bankingService;
	}
	public void setBankingService(BankingServices bankingService) {
		this.bankingService = bankingService;
	}

	@RequestMapping(value="/login",method=RequestMethod.GET) 
	public String showMessage(Model model) {											

		Account account=new Account();
		model.addAttribute("log",account);
		model.addAttribute("compNameObj","capgemini");
		return "Login";
	}
	@RequestMapping(value="/ValidateUser" ,method=RequestMethod.POST)
	public String validateUserDetails( @ModelAttribute(value="log")@Valid Account acc,Model model) {

		try {
			if(bankingService.validateUser(acc.getAccountNo(), acc.getPinNumber())){
				model.addAttribute("loginSuccessMsg","Login successful !");
				return "Login";
			}
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {

			e.printStackTrace();
		}
		return "OpenAccount";
	}
	@RequestMapping(value="/openAccount",method=RequestMethod.GET)
	public String displayOpenAccountPage(Model model) {
		model.addAttribute("open", new Account());
		return "OpenAccount";
	}
	@RequestMapping(value="/Insert", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="open") @Valid Account account,Model model) {
		try {
			try {
				bankingService.getAccountDetails(account.getAccountNo());
			} catch (AccountNotFoundException e) {

				e.printStackTrace();
			}
			bankingService.openAccount(account.getAccountType(),account.getAccountBalance());
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException e) {

			e.printStackTrace();
		}
		model.addAttribute("msg","account is successfully opened");
		return "OpenAccount";

	}
	@RequestMapping(value="/depositAmount",method=RequestMethod.GET)
	public String displayDepositAmountPage(Model model) {
		model.addAttribute("deposit", new Account());
		return "DepositAmount";

	}

	@RequestMapping(value="/Deposit", method=RequestMethod.POST)
	public String depositAmountDetails(@ModelAttribute(value="deposit") @Valid Account account,BindingResult result,Model model,@RequestParam("amount")float amount ) {

		try {
			bankingService.depositAmount(account.getAccountNo(), amount);
		} catch (AccountNotFoundException | BankingServicesDownException | AccountBlockedException e) {

			e.printStackTrace();
		}
		model.addAttribute("depositSuccessMsg","account is successfully deposited");
		return "DepositAmount";
	}


	@RequestMapping(value="/withdrawAmount",method=RequestMethod.GET)
	public String displayWithdrawAmountPage(Model model) {
		model.addAttribute("withdraw", new Account());
		return "WithdrawAmount";

	}

	@RequestMapping(value="/Withdraw", method=RequestMethod.POST)
	public String withdrawAmountDetails(@ModelAttribute(value="withdraw") @Valid Account account,BindingResult result,Model model,@RequestParam("amount")float amount ) {

		try {
			bankingService.withdrawAmount(account.getAccountNo(), amount, account.getPinNumber());
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}

		model.addAttribute("withdrawSuccessMsg","account is successfully withdrawn");
		return "WithdrawAmount";
	}
	@RequestMapping(value="/fundTransfer",method=RequestMethod.GET)
	public String displayFundTransferPage(Model model) {
		model.addAttribute("fundTransfer", new Account());
		return "FundTransfer";

	}

	@RequestMapping(value="/FundTransfer", method=RequestMethod.POST)
	public String fundTransferDetails(@ModelAttribute(value="fundTransfer") @Valid Account account,BindingResult result,Model model,@RequestParam("accountNoTo")long accountNoTo,@RequestParam("accountNoFrom")long accountNoFrom
			,@RequestParam("transferAmount")float transferAmount,@RequestParam("pinNumber")int pinNumber) {

		try {
			bankingService.fundTransfer(accountNoTo, accountNoFrom, transferAmount,pinNumber);
		} catch (InsufficientAmountException | AccountNotFoundException | InvalidPinNumberException
				| BankingServicesDownException | AccountBlockedException e) {
			e.printStackTrace();
		}
		model.addAttribute("fundTransferSuccessMsg","amount is successfully transferred");
		return "FundTransfer";
	}
	
	@RequestMapping(value="/getAllTransactions",method=RequestMethod.GET)
	public String displayAllTransactionsPage(Model model) {
		//model.addAttribute("transactions", new Account());
		return "GetAllTransactionsInputPage";

	}

	@RequestMapping(value="/GetAllTransactions", method=RequestMethod.POST)
	public String allTransactionsDetails(Model model,@RequestParam("accountNo")long accountNo) {

		
			try {
				model.addAttribute("msgList",bankingService.getAccountAllTransaction(accountNo));
			} catch (BankingServicesDownException | AccountNotFoundException e) {
				
				e.printStackTrace();
			}
	
		model.addAttribute("showTransactionsMsg","These are your transactions");
		return "GetAllTransactionsOutputPage";
	}
}



