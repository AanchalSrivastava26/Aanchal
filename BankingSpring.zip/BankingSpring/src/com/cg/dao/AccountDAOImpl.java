package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.beans.Account;


@Repository																
@Transactional		
public class AccountDAOImpl implements AccountDAO{
	@PersistenceContext	
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Account save(Account account) {

		entityManager.persist(account);
		entityManager.flush();
		return account;
	}

	@Override
	public boolean update(Account account) {

		entityManager.merge(account);
		entityManager.flush();
		return true;
	}

	@Override
	public Account findOne(long accountNo) {

		return entityManager.find(Account.class, accountNo);
	}

	@Override
	public List<Account> findAll() {

		return entityManager.createQuery("from Account a").getResultList();
	}

}
