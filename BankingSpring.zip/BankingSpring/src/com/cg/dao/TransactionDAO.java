package com.cg.dao;
import java.util.List;

import com.cg.beans.Transaction;



public interface TransactionDAO {
	
	Transaction save(Transaction transaction);
	boolean update(Transaction transaction);
	Transaction findOne(int transactionId);
	List<Transaction> findAll();
}