package com.cg.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;
import com.cg.beans.Transaction;

@Repository																
@Transactional		
public class TransactionDAOImpl implements TransactionDAO {
	@PersistenceContext	
	EntityManager entityManager=null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Transaction save(Transaction transaction) {

		entityManager.persist(transaction);
		entityManager.flush();
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {

		entityManager.merge(transaction);
		entityManager.flush();
		return true;
	}

	@Override
	public Transaction findOne(int transactionId) {

		return entityManager.find(Transaction.class, transactionId);
	}

	@Override
	public List<Transaction> findAll() {

		return 	entityManager.createQuery("from Transaction a").getResultList();

	}

}
