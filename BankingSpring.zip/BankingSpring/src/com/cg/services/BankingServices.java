package com.cg.services;

import java.util.List;

import com.cg.beans.Account;
import com.cg.beans.Transaction;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.BankingServicesDownException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidAccountTypeException;
import com.cg.exceptions.InvalidAmountException;
import com.cg.exceptions.InvalidPinNumberException;



public interface BankingServices {
	boolean validateUser(long accountNo,int pinNumber)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;

	Account openAccount(String accountType,float initBalance)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;

	float depositAmount(long accountNo,float amount)
			throws
			AccountNotFoundException,BankingServicesDownException, AccountBlockedException;

	float withdrawAmount(long accountNo,float amount,int pinNumber)
			throws InsufficientAmountException,
			AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException;

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException  ;

	Account getAccountDetails(long accountNo)
			throws  AccountNotFoundException,BankingServicesDownException;

	List<Account> getAllAccountDetails()
			throws BankingServicesDownException;

	List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException;


	public String accountStatus(long accountNo)
			throws BankingServicesDownException,
			AccountNotFoundException, AccountBlockedException;
}