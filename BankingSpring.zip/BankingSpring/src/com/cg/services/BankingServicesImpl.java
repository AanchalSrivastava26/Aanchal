package com.cg.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Account;
import com.cg.beans.Transaction;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.dao.TransactionDAO;
import com.cg.dao.TransactionDAOImpl;
import com.cg.exceptions.AccountBlockedException;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.exceptions.BankingServicesDownException;
import com.cg.exceptions.InsufficientAmountException;
import com.cg.exceptions.InvalidAccountTypeException;
import com.cg.exceptions.InvalidAmountException;
import com.cg.exceptions.InvalidPinNumberException;

@Service
public class BankingServicesImpl implements BankingServices {
	@Autowired
	AccountDAO accountdao;
	@Autowired
	TransactionDAO transactiondao;

	public AccountDAO getAccountdao() {
		return accountdao;
	}
	public void setAccountdao(AccountDAO accountdao) {
		this.accountdao = accountdao;
	}
	public TransactionDAO getTransactiondao() {
		return transactiondao;
	}
	public void setTransactiondao(TransactionDAO transactiondao) {
		this.transactiondao = transactiondao;
	}

	@Override
	public boolean validateUser(long accountNo, int pinNumber)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account = null;
		try {
			account = getAccountDetails(accountNo);
		} catch (AccountNotFoundException e) {

			e.printStackTrace();
		}
		if(accountNo==account.getAccountNo() && pinNumber==account.getPinNumber())
			return true;
		else
			return false;
	}
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account.setPinNumber((int)(Math.random()*1111));
		account.setStatus("active");
		accountdao.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(amount+account.getAccountBalance());
		transactiondao.save(new Transaction(amount, "deposit", account));
		accountdao.update(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		transactiondao.save(new Transaction(amount, "withdrawl", account));
		accountdao.update(account);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account accountTo=getAccountDetails(accountNoTo);
		Account accountFrom=getAccountDetails(accountNoFrom);
		if(pinNumber==accountFrom.getPinNumber()) {

			if(accountFrom.getAccountBalance()>transferAmount) {
				accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
				accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
				transactiondao.save(new Transaction(transferAmount, "transferred",accountTo));
				accountdao.update(accountTo);
				transactiondao.save(new Transaction(transferAmount, "transferred",accountFrom));
				accountdao.update(accountFrom);
				return true;
			}
			else 

				throw new InsufficientAmountException("insufficient amount");

		}
		else
			throw new InvalidPinNumberException("please enter correct pin");
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountdao.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account not found for accountNo"+accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		return accountdao.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {

		return transactiondao.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account acc=getAccountDetails(accountNo);
		if(acc.getStatus().equals("blocked"))

			return "blocked";
		else
			return "active";
	}

}
