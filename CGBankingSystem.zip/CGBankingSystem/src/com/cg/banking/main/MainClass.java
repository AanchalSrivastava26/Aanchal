package com.cg.banking.main;


import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class MainClass {
    public static void main(String[] args) {
     
        Scanner sc=new Scanner(System.in);
        BankingServices bServices=new BankingServicesImpl();
        int num=0;
        try {
            Account account1=bServices.openAccount("savings", 4000);
            Account account2=bServices.openAccount("current", 3000);
            while(num!=7) {
                System.out.println("\n1.deposit amount\n2.withdraw amount\n3.transfer amount\n4.get AccountDetails\n5.get all account details"
                        + "\n6.get all account transactions\n7.exit\nenter number: ");
                num=sc.nextInt();
                switch (num) {
                case 1:
                    System.out.println("enter deposit amount: ");
                    System.out.println(bServices.depositAmount(account1.getAccountNo(), sc.nextInt()));
                    break;
                case 2:
                    System.out.println("enter withdrawl amount: ");
                    System.out.println(bServices.withdrawAmount(account1.getAccountNo(), sc.nextInt(), account1.getPinNumber()));
                    break;
                case 3:
                    System.out.println("enter amount to transfer: ");
                    System.out.println(bServices.fundTransfer(account2.getAccountNo(), account1.getAccountNo(), sc.nextInt(), 
                            account1.getPinNumber()));
                    break;
                case 4:
                    System.out.println(bServices.getAccountDetails(account1.getAccountNo()));
                    break;
                case 5:
                    System.out.println(bServices.getAllAccountDetails());
                    break;
                case 6:
                    System.out.println(bServices.getAccountAllTransaction(account1.getAccountNo()));
               
                    break;
                default:
                    System.out.println("you entered default case");
                    break;
                }
            }
            
        } catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException | AccountNotFoundException | AccountBlockedException | InsufficientAmountException | InvalidPinNumberException  e) {
            e.printStackTrace();
        }
    }
}
