package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO;
	private TransactionDAO transactionDAO;
	public BankingServicesImpl() {
		accountDAO=new AccountDAOImpl();
		transactionDAO=new TransactionDAOImpl();
	}
	public BankingServicesImpl(AccountDAO accountDAO) {
		super();
		this.accountDAO = accountDAO;
	}

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account.setPinNumber((int)(Math.random()*11182));
		account.setStatus("active");
		accountDAO.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(amount+account.getAccountBalance());
		transactionDAO.save(new Transaction(amount, "deposit", account));
		accountDAO.update(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		account.setAccountBalance(account.getAccountBalance()-amount);
		transactionDAO.save(new Transaction(amount, "withdrawl", account));
		accountDAO.update(account);
		return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account accountTo=getAccountDetails(accountNoTo);
		Account accountFrom=getAccountDetails(accountNoFrom);
		if(accountTo.getAccountBalance()>transferAmount) {
			accountTo.setAccountBalance(accountTo.getAccountBalance()-transferAmount);
			return true;
		}
		else { 
			accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
			return true;
		}
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException("Account not found for accountNo"+accountNo);
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {

		return transactionDAO.findAll();
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account acc=getAccountDetails(accountNo);
		if(acc.getStatus().equals("blocked"))
	
		return "blocked";
		else
		return "active";
	}
}
