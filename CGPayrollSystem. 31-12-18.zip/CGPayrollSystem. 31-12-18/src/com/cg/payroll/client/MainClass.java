package com.cg.payroll.client;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


public class MainClass {

	public static void main(String[] args) {
		/*	Associate[] associates=new Associate[5];

		associates[0] =new Associate(200,30000,"Aanchal","Srivastava","xyz","trainee","jyup1234","aanchal@gmail.com",new Salary(30000,100,200),new BankDetails("HDFC","1245hdfc"));

		associates[1]=new Associate(300,10000,"abc","gef","xyz","trainee","jyup000","abc@gmail.com",new Salary(20000,100,200),new BankDetails("icici","1245icici"));

		associates[2]=new Associate(200,9000,"xyz","abc","xyz","analyst","jyup1000","xyz@gmail.com",new Salary(1000,100,200),new BankDetails("citi bank","1245citi"));

		associates[3]=new Associate(200,10000,"preeti","abc","xyz","trainee","jyup1234","preeti@gmail.com",new Salary(1000,100,200),new BankDetails("HDFC","1111hdfc"));

		associates[4]=new Associate(200,10000,"madhu","Srivastava","xyz","trainee","jyup1234","madhu@gmail.com",new Salary(10000,100,200),new BankDetails("icici","1245icici"));

		for(Associate associate5 : associates) {
			if(associate5.getBankDetails().getBankName()=="HDFC" && associate5.getSalary().getBasicSalary()>=20000)
				System.out.println(associate5.getFirstName());*/

		PayrollServices payrollServices=new PayrollServicesImpl();
		int associateId=payrollServices.acceptAssociateDetails("abc", "xyz", 10000, "abc", "analyst", "gdhg7789", "agha@gamail.com", 30000, 1233, 45676, 12344656, "hdfc", "hdfc6798");
		System.out.println("ASSOCIATE ID="+associateId);
		try {
			Associate associate=payrollServices.getAssociateDetails(101);
			Associate[] associate1=payrollServices.getAllAssociatesDetails();
		
		} catch (AssociateDetailsNotFoundException e) {
			
			e.printStackTrace();
		}

	}

}







