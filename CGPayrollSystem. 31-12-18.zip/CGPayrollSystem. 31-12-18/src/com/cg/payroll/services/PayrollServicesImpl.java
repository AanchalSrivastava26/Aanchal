package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, int yearlyInvestmentUnder80C,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode) {
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
				new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber,bankName, ifscCode));
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateId);
		associate.getSalary().setHra((40/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyanceAllowance((30/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setPersonalAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance((20/100)*associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getEpf()+
				associate.getSalary().getCompanyPf()+associate.getSalary().getHra()+associate.getSalary().getConveyanceAllowance()+
				associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance());
		int annualGrossSalary=(associate.getSalary().getGrossSalary())*12;
		int annualTax=0;
		if(annualGrossSalary>0 && annualGrossSalary<=25000)
			annualTax=0;
		else if(annualGrossSalary>250000 && annualGrossSalary<=500000)
		annualTax=annualGrossSalary-10/100*500000;
		else if(annualGrossSalary>500000 && annualGrossSalary<=1000000)
			annualTax=20/100*annualGrossSalary;
		else
			annualTax=30/100*annualGrossSalary;
		int monthlyTax=annualTax/12;
			
		return 0;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("Associate details not found for associateId"+associateId);
		return associate;
	}

	@Override
	public Associate[] getAllAssociatesDetails() {

		return associateDAO.findAll();
	}

}
