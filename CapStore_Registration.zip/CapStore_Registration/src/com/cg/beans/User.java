package com.cg.beans;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="user_register")
public class User {
	
	@Id
	private String userId;
	@NotEmpty(message="first name is mandatory")
	@Pattern(regexp="[A-Z][a-z]*",message="name should start with capital letters and"+" "+"only characters are allowed")
	private String firstName;
	@NotEmpty(message="last name is mandatory")
	private String lastName;
	@NotEmpty(message="contact number is mandatory")
	 @Size(min=0,max=10,message="contact number must be of 10 digits")
	private String contact;
	@Email(message="invalid email address")
	private String email;
	@NotEmpty(message="password is mandatory")
	@Pattern(regexp="([a-z]|[A-Z]|[0-9]|[\\W]){4}[a-zA-Z0-9\\W]{3,11}",message =" "+ "Invalid password format")
	private String password;
	private String encryptedPassword;

	private String userRole;

	@OneToMany(mappedBy="user", cascade=CascadeType.ALL)
	private List<Address> addresses;

	public User() {}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public User(String userId, String firstName, String lastName, String contact, String email, List<Address> addresses,
			String password, String encryptedPassword, String userRole) {
		super();
		this.userId = userId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contact = contact;
		this.email = email;
		this.addresses = addresses;
		this.password = password;
		this.encryptedPassword = encryptedPassword;
		this.userRole = userRole;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", contact=" + contact
				+ ", email=" + email + ", password=" + password + ", encryptedPassword=" + encryptedPassword
				+ ", userRole=" + userRole + ", addresses=" + addresses + "]";
	}












}
