package com.cg.controllers;

import java.util.ArrayList;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.beans.Address;
import com.cg.beans.User;
import com.cg.services.RegisterServices;

@Controller
public class RegisterController {
	@Autowired
	RegisterServices registerServices;
	ArrayList<String>stateList;

	public RegisterServices getRegisterServices() {
		return registerServices;
	}
	public void setRegisterServices(RegisterServices registerServices) {
		this.registerServices = registerServices;
	}

	@RequestMapping(value="/addUser",method=RequestMethod.GET)
	public String displayRegisterPage(Model model) {
		model.addAttribute("add", new User());

		return "RegisterPage";
	}
	@RequestMapping(value="/Insert", method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="add") @Valid User register,BindingResult result,Model model) {


		registerServices.addUser(register);
		model.addAttribute("address", new Address());
		return "AddressPage";
	}

	@ModelAttribute("stateList")
	public ArrayList<String> createStateList() {
		ArrayList<String> stateList=new ArrayList<>();
		stateList.add("Andhra Pradesh");stateList.add("Arunachal Pradesh");stateList.add("Assam");
		stateList.add("Bihar");stateList.add("Chhattisgarh");stateList.add("Goa");stateList.add("Gujarat");
		stateList.add("Haryana");stateList.add("Himachal Pradesh");stateList.add("Jammu & Kashmir");
		stateList.add("Jharkhand");stateList.add("Karnataka");stateList.add("Kerala");stateList.add("Madhya Pradesh");
		stateList.add("Maharashtra");stateList.add("Manipur");stateList.add("Meghalaya");stateList.add("Mizoram");
		stateList.add("Nagaland");stateList.add("Odisha");stateList.add("Punjab");stateList.add("Rajasthan");
		stateList.add("Sikkim");stateList.add("Tamil Nadu");stateList.add("Telangana");stateList.add("Tripura");
		stateList.add("Uttarakhand");stateList.add("Uttar Pradesh");stateList.add("West Bengal");
		return stateList;

	}

	@RequestMapping(value="/Insert1", method=RequestMethod.POST)
	public String addAddressDetails(@ModelAttribute(value="stateList") 
	ArrayList<String> stateList,@Valid Address address,BindingResult result,Model model) {

		registerServices.addAddress(address);
		model.addAttribute("msg1","data is successfully added");
		return "AddressPage";
	}

}


