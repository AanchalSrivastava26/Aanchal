package com.cg.dao;

import com.cg.beans.Address;
import com.cg.beans.User;

public interface RegisterDao {

	public User addUser(User register);
	public Address addAddress(Address address);
	
}
