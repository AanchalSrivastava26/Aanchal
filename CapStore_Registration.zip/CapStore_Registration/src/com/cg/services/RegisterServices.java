package com.cg.services;

import com.cg.beans.Address;
import com.cg.beans.User;

public interface RegisterServices {

	public 	User addUser(User register);
	public Address addAddress(Address address,User user);
	//public User findOne(String userId);
}
