package com.cg.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.beans.Address;
import com.cg.beans.User;
import com.cg.dao.RegisterDao;

@Service
public class RegisterServicesImpl implements RegisterServices {
	@Autowired
	RegisterDao registerDao;
	static int num=1000;
	static int num1=1000;

	public RegisterDao getRegisterDao() {
		return registerDao;
	}
	public void setRegisterDao(RegisterDao registerDao) {
		this.registerDao = registerDao;
	}

	@Override
	public User addUser(User register) {

		int t=num++;
		
		   String str1 = Integer.toString(t);
		   StringBuilder str=new StringBuilder(str1);
		   str.append("U"+str);
		   register.setUserId(str.toString());
		
		return registerDao.addUser(register);

	}
	@Override
	public Address addAddress(Address address) {
		int t=num1++;
		
		   String str2 = Integer.toString(t);
		   StringBuilder str3=new StringBuilder(str2);
		   str3.append("U"+str3);
		address.setAddress_id(str3.toString());
	//	address.setUser(user);
		
		return registerDao.addAddress(address);
	}
/*	@Override
	public User findOne(String userId) {
	
		return registerDao.findOne(userId);
	}*/
}
