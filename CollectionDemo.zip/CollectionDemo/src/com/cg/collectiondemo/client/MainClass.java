package com.cg.collectiondemo.client;

import com.cg.collectiondemo.collection.ListClassesDemo;

public class MainClass {
	public static void main(String[] args) {
	ListClassesDemo.arrayListClassDemo();
		
	}

}
