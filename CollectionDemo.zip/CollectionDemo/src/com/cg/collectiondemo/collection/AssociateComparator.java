package com.cg.collectiondemo.collection;

import java.util.Comparator;

import com.cg.collectiondemo.beans.Associate;

public class AssociateComparator implements Comparator<Associate> {

	@Override
	public int compare(Associate associate1, Associate associate2) {

		return associate1.compareTo(associate2);
	}

}
