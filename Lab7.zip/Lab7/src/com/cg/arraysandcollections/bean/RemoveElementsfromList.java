package com.cg.arraysandcollections.bean;

import java.util.List;

public class RemoveElementsfromList {
	public static List<Integer> removeElements(List<Integer> list1,List<Integer> list2){
		list1.removeAll(list2);
		return list1;
	}
}
