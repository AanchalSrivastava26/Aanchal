package com.cg.arraysandcollections.bean;

public class ReverseAndSort{
	
	public static int[] getSorted(int[] array) {
		for (int i = 0; i < array.length; i++) {
			StringBuilder sb=new StringBuilder(Integer.toString(array[i]));
			array[i]=Integer.parseInt(sb.reverse().toString());
			sb.delete(0, sb.length());
		}
		for(int i=0;i<array.length;i++) {
			for (int j = 0; j < array.length; j++)
				if(array[i]<array[j]) {
					int temp=array[j];
					array[j]=array[i];
					array[i]=temp;
				}
		}
		return array;
		
	}
}
