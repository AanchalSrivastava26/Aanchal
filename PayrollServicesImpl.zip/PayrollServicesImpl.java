package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDAO=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, int yearlyInvestmentUnder80C,
			String department, String designation, String pancard, String emailId, int basicSalary, int epf,
			int companyPf, int accountNumber, String bankName, String ifscCode) {
		Associate associate=new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
				new Salary(basicSalary, epf, companyPf), new BankDetails(bankName, ifscCode));
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		
		Associate associate=this.getAssociateDetails(associateId);
		if(associate==null)
			throw new AssociateDetailsNotFoundException("id not found");
		int annualTax=0;
		int hra=(associate.getSalary().getBasicSalary()*40)/100;
		int conveyanceAllowance=(associate.getSalary().getBasicSalary()*30)/100;
		int otherAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		int personalAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		int grossSalary=associate.getSalary().getBasicSalary()+hra+conveyanceAllowance+otherAllowance
				+personalAllowance;
		int annualSalary=grossSalary*12;
		int taxable=annualSalary-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()*12
				-associate.getSalary().getCompanyPf();
		if(taxable<250000)
			annualTax=0;
		if(taxable>250000 && taxable<=500000)
			annualTax=annualTax+((taxable-250000)*10)/100;
		if(taxable>500000 && taxable<=1000000)
			annualTax=25000+((taxable-500000)*20)/100;
		if(taxable>1000000)
			annualTax=125000+((taxable-1000000)*30)/100;
		int monthlyTax=annualTax/12;
		int netSalary=grossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-monthlyTax;
		
		return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {

		return associateDAO.findOne(102);
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {

		return associateDAO.findAll();
	}

}
