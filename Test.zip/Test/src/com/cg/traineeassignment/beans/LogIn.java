package com.cg.traineeassignment.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_trainees")
public class LogIn {
	@Id
	@Column(name="user_name",length=20)	
	private String userName;
	@Column
	private String password;
	public LogIn() {}
	
	@NotEmpty(message="username is required")
	@Size(min=5,message="size should be atleast 5")
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	@NotEmpty(message="password is required")
	@Size(min=5,message="size should be atleast 5")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "userName=" + userName + ", password=" + password;
	}
	
	
	
	

}
