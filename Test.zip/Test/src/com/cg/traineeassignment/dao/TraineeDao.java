package com.cg.traineeassignment.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.traineeassignment.beans.LogIn;
import com.cg.traineeassignment.beans.TraineeRegister;

public interface TraineeDao {
	public boolean isUserExist(String uName);
	public LogIn validateUser(LogIn login);

	public ArrayList<TraineeRegister> getAllUserDetails();
	public boolean deleteTrainee(int traineeId);
	
	public 	TraineeRegister addTrainee(TraineeRegister register);
	public TraineeRegister retrieveTrainee(int traineeId);
	public ArrayList<TraineeRegister> retrieveAllTrainee();
	public TraineeRegister updateTrainee(TraineeRegister traineeRegister);

}
